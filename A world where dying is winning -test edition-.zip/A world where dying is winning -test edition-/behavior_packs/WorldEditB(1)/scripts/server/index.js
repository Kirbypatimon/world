import { world } from "@minecraft/server";
world.afterEvents.worldLoad.subscribe(async () => {
    const { print, printerr } = await import("./util.js");
    const { default: isWhitelistEnabled } = await import("whitelist.js");
    const { contentLog, Server, configuration } = await import("../library/Minecraft.js");
    const { getSession, removeSession } = await import("./sessions.js");
    const { PlayerUtil } = await import("./modules/player_util.js");
    const { default: config } = await import("config.js");
    await import("./commands/command_list.js");
    await import("./tools/tool_list.js");
    await import("./ui/index.js");
    // Check if configuration is properly loaded
    if (!config.commandPrefix) {
        world.getAllPlayers().forEach((player) => printerr("WorldEdit failed to load configuration!", player, false));
        throw new Error('Configuration is not properly loaded! If this is a server, "variables.json" is required.');
    }
    Server.setMaxListeners(256);
    configuration.multiThreadingTimeBudget = config.asyncTimeBudget;
    const activeBuilders = [];
    let ready = false;
    Server.on("ready", (ev) => {
        contentLog.debug(`World has been loaded in ${ev.loadTime} ticks!`);
        ready = true;
    });
    Server.on("playerLoaded", (ev) => {
        contentLog.debug(`player ${ev.player.name} loaded.`);
        if (ready)
            makeBuilder(ev.player);
    });
    Server.on("playerLeave", (ev) => {
        contentLog.debug(`player ${ev.playerName} left.`);
        removeBuilder(ev.playerId);
    });
    Server.on("tick", () => {
        if (!ready)
            return;
        for (const player of world.getPlayers()) {
            if (!activeBuilders.includes(player)) {
                if (PlayerUtil.isHotbarStashed(player)) {
                    PlayerUtil.restoreHotbar(player);
                }
                if (makeBuilder(player)) {
                    // Attempt to make them a builder.
                    print("worldedit.permission.granted", player);
                    continue;
                }
            }
        }
        for (let i = activeBuilders.length - 1; i >= 0; i--) {
            try {
                // Just testing
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const name = activeBuilders[i].name;
            }
            catch {
                contentLog.debug("A builder no longer exists!");
                activeBuilders.splice(i, 1);
                continue;
            }
            const builder = activeBuilders[i];
            if (hasWorldEdit(builder)) {
                getSession(builder);
            }
            else {
                removeBuilder(builder.id);
                contentLog.log(`${builder.name} has been revoked of their worldedit permissions.`);
                print("worldedit.permission.revoked", builder);
            }
        }
    });
    function makeBuilder(player) {
        if (hasWorldEdit(player) && !activeBuilders.includes(player)) {
            getSession(player);
            activeBuilders.push(player);
            contentLog.log(`${player.name} has been given worldedit permissions.`);
            return true;
        }
        return false;
    }
    function removeBuilder(player) {
        let i = -1;
        do {
            i = activeBuilders.findIndex((p) => {
                try {
                    return p.id == player;
                }
                catch (e) {
                    return true;
                }
            });
            if (i != -1)
                activeBuilders.splice(i, 1);
        } while (i != -1);
        removeSession(player);
        contentLog.debug("Removed player from world edit!");
    }
    function hasWorldEdit(player) {
        if (!isWhitelistEnabled())
            return true;
        for (const tag of player.getTags()) {
            if (tag.startsWith("worldedit"))
                return true;
        }
        return false;
    }
});
