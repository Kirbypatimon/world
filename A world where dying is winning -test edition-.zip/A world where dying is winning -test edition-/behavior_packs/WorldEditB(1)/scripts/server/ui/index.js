import "./hotbar_menus.js";
import "./config_menu.js";
import "./select_region_tool.js";
import "./select_gen_tool.js";
